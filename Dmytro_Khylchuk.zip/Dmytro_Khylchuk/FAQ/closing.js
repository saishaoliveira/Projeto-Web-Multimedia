const details = Array.from(document.querySelectorAll('details'))
  .filter(detail => !detail.closest('.outside'));

details.forEach((detail, index) => {
  detail.addEventListener('toggle', () => {
    if (detail.open) {
      switch (index) {
        case 0:
          details[1].open = false;
          details[2].open = false;
          details[3].open = false;
          break;
        case 1:
          details[0].open = false;
          details[2].open = false;
          details[3].open = false;
          break;
        case 2:
          details[0].open = false;
          details[1].open = false;
          details[3].open = false;
          break;
        case 3:
          details[0].open = false;
          details[1].open = false;
          details[2].open = false;
          break;
      }
    }
  });
});